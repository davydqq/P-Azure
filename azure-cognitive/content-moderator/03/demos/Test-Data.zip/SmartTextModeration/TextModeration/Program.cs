﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.CognitiveServices.ContentModerator;
using Microsoft.CognitiveServices.ContentModerator.Contract.Text;

namespace TextModeration
{
    class Program
    {
        // Azure Content Moderator
        private const string cEndpoint = "https://eastus.api.cognitive.microsoft.com/contentmoderator/moderate/v1.0";
        private const string cSubscriptionKey = "7eb456e56f2841cfbdfaf59bafdb8728";

        // Files to Test
        private const string cStrText1 = @"C:\ps demos\test.txt";

        static void Main(string[] args)
        {
            ProcessTextRequest(cStrText1);
            Console.ReadLine();
        }

        public static void ProcessTextRequest(string file)
        {
            Task.Run(async () =>
            {
                Console.WriteLine(Environment.NewLine);

                Console.WriteLine(ScreenTextResults(await ScreenText(file)));
            });
        }

        public static async Task<ScreenTextResult> ScreenText(string file)
        {
            ScreenTextResult tr = null;
            ModeratorClient client = new ModeratorClient(cSubscriptionKey, cEndpoint);

            if (File.Exists(file))
                tr = await client.ScreenTextAsync(File.ReadAllText(file), Constants.MediaType.Plain, "eng", true,
                    true, true, string.Empty);

            return tr;
        }

        // Print Results
        public static string ScreenTextResults(ScreenTextResult res)
        {
            return $"PII IP Address: {res.PII.IPA[0].Text} " +
                $"{Environment.NewLine}" + $"PII Email: {res.PII.Email[0].Text}" +
                $"{Environment.NewLine}" + $"Term: {res.Terms[0].Term}";
        }
    }
}
