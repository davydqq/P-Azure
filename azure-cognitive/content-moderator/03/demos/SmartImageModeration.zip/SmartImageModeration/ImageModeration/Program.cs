﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.CognitiveServices.ContentModerator;
using Microsoft.CognitiveServices.ContentModerator.Contract.Image;

namespace ImageModeration
{
    class Program
    {
        // Azure Content Moderator
        private const string cEndpoint = "https://eastus.api.cognitive.microsoft.com/contentmoderator/moderate/v1.0";
        private const string cSubscriptionKey = "7eb456e56f2841cfbdfaf59bafdb8728";

        // Files to Test
        private const string cStrImage1 = @"C:\ps demos\quote.jpg";

        static void Main(string[] args)
        {
            ProcessImageRequest(cStrImage1);
            Console.ReadLine();
        }

        public static void ProcessImageRequest(string file)
        {
            Task.Run(async () => {
                Console.WriteLine(Environment.NewLine);

                //Console.WriteLine(EvaluateImageResults(await EvaluateImage(file)));
                //Console.WriteLine(FindFacesImageResults(await FindFacesImage(file)));
                Console.WriteLine(OcrImageResults(await OcrImage(file)));
            });
        }

        public static async Task<EvaluateImageResult> EvaluateImage(string image)
        {
            EvaluateImageResult ev = null;
            ModeratorClient client = new ModeratorClient(cSubscriptionKey, cEndpoint);

            if (File.Exists(image))
                ev = await client.EvaluateImageAsync(
                    new FileStream(image, FileMode.Open, FileAccess.Read), false);

            return ev;
        }

        public static async Task<DetectFacesResult> FindFacesImage(string image)
        {
            DetectFacesResult df = null;
            ModeratorClient client = new ModeratorClient(cSubscriptionKey, cEndpoint);

            if (File.Exists(image))
                df = await client.DetectFacesImageAsync(
                    new FileStream(image, FileMode.Open, FileAccess.Read), false);

            return df;
        }

        public static async Task<OcrImageResult> OcrImage(string image)
        {
            OcrImageResult df = null;
            ModeratorClient client = new ModeratorClient(cSubscriptionKey, cEndpoint);

            if (File.Exists(image))
                df = await client.OCRImageAsync(
                    new FileStream(image, FileMode.Open, FileAccess.Read), false);

            return df;
        }

        // Print Results
        public static string EvaluateImageResults(EvaluateImageResult res)
        {
            return $"AdultClassificationScore: {res.AdultClassificationScore.ToString()}" +
                $"{Environment.NewLine}RacyClassificationScore: {res.RacyClassificationScore.ToString()}";
        }

        public static string FindFacesImageResults(DetectFacesResult res)
        {
            return $"Number of faces found: {res.Count.ToString()}";
        }

        public static string OcrImageResults(OcrImageResult res)
        {
            return $"Text Extracted: {res.Text.ToString()}";
        }
    }
}
